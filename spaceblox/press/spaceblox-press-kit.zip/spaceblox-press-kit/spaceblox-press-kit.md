# Spaceblox: Press Kit

## Factsheet
- **Game:** Spaceblox
- **Developer:** Giga Sichinava (gix0n), solo developer
- **Release date:** 1 September 2026
- **Current version:** 1.1.0
- **Platforms:** Android (Google Play), plus a free browser version
- **Price:** Free
- **Genre:** Puzzle / Logic
- **Engine:** Godot
- **Languages:** English, Spanish, German, French, Polish, Georgian, Ukrainian
- **Google Play:** https://play.google.com/store/apps/details?id=com.spaceblox.game
- **Browser version:** https://geeks0n-byte.github.io/spaceblox/play/
- **Website:** https://geeks0n-byte.github.io/spaceblox/
- **Press contact:** giga.sichinava@gmail.com

## One-liner
A calm color-logic puzzle, free on Google Play.

## Short description (about 50 words)
Spaceblox is a calm color-logic puzzle. Fill the grid with yellow, blue, green and purple blocks under a few strict rules: never three of a color in a row, keep yellow and blue balanced, respect = and × links, and slide purple hoppers into place. Pure logic, no fail state.

## Full description
Spaceblox is the first released game from solo developer Giga Sichinava. It's a calm color-logic puzzle, not a match-3.

Each level is a grid of empty cells. You fill it with colored blocks, and the finished board has to follow a few strict rules. You can never have three of the same color in a row. Yellow and blue have to stay balanced. Green counts as both colors at once, which makes it your most flexible tool and also the easiest way to trip yourself up.

As the campaign goes on, new ideas join in. Purple tiles fill a cell but, like green, don't count toward the yellow and blue balance. Some pairs of cells are linked: = means they must match and × means they must differ, with green counting as a match either way and purple only matching purple. Purple hoppers jump between two linked cells: tap one to slide it along its arrow, unless another purple is blocking the way.

Every level has a clean solution you can reach with pure logic, no guessing. There's no fail state, so you can take your time, undo and think. The campaign runs from easy to medium to hard, and it's made for short, relaxing sessions on your phone.

## Key features
- Color-logic puzzles built on a few simple, strict rules
- Four tile colors, = and × links, and purple hoppers you slide into place
- Every level is solvable with logic alone, no guessing
- No fail state: play at your own pace
- Campaign from easy to medium to hard
- Free on Google Play, with a browser version to try it instantly
- Achievements and Google Play Games cloud save
- Colorblind-friendly mode and screen reader support
- Available in 7 languages

## About the developer
Giga "gix0n" Sichinava is a solo indie developer who makes small, calm games in Godot. Spaceblox is the first game Giga has released, designed, programmed and published solo.

## Assets
- Logo (transparent PNG): assets/logo.png (preview on dark: assets/logo_on_dark.png)
- App icon (512 × 512): assets/app_icon_512.png
- Screenshots (5 to 6, phone portrait): assets/screenshots/01_main_menu.png, assets/screenshots/02_green_tiles.png, assets/screenshots/03_purple_hoppers.png, assets/screenshots/04_links.png, assets/screenshots/05_level41_gameplay.png, assets/screenshots/06_victory.png
- Key art / banner (1920 × 1080): assets/key_art_1920x1080.png
- Short gameplay GIF or trailer: assets/gameplay.gif

## Usage
You're welcome to use the text and assets in this kit for articles, videos, newsletters and features about Spaceblox.
